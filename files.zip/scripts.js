// ════════════════════════════════════════════════════════════
// SKY GRADIENT — sin debug, hora real
// ════════════════════════════════════════════════════════════
const SKY_PHASES = [
  { h: 0,  colors: ['rgba(10,10,26,0.90)',   'rgba(13,27,62,0.90)',   'rgba(26,26,46,0.90)']  },
  { h: 4,  colors: ['rgba(13,27,62,0.90)',   'rgba(26,26,46,0.90)',   'rgba(45,27,105,0.90)'] },
  { h: 5,  colors: ['rgba(26,5,51,0.90)',    'rgba(160,50,90,0.90)',  'rgba(244,132,95,0.90)'] },
  { h: 6,  colors: ['rgba(244,132,95,0.90)', 'rgba(247,178,103,0.90)','rgba(252,227,138,0.90)'] },
  { h: 7,  colors: ['rgba(135,206,235,0.90)','rgba(184,224,255,0.90)','rgba(252,227,138,0.90)'] },
  { h: 10, colors: ['rgba(79,163,224,0.90)', 'rgba(135,206,235,0.90)','rgba(204,232,245,0.90)'] },
  { h: 12, colors: ['rgba(30,120,200,0.90)', 'rgba(79,163,224,0.90)', 'rgba(135,206,235,0.90)'] },
  { h: 15, colors: ['rgba(79,163,224,0.90)', 'rgba(135,206,235,0.90)','rgba(184,224,255,0.90)'] },
  { h: 17, colors: ['rgba(244,132,95,0.90)', 'rgba(247,178,103,0.90)','rgba(255,209,102,0.90)'] },
  { h: 18, colors: ['rgba(232,83,59,0.90)',  'rgba(192,57,43,0.90)',  'rgba(142,68,173,0.90)'] },
  { h: 19, colors: ['rgba(44,22,84,0.90)',   'rgba(142,68,173,0.90)', 'rgba(244,132,95,0.90)'] },
  { h: 20, colors: ['rgba(26,5,51,0.90)',    'rgba(44,22,84,0.90)',   'rgba(13,27,62,0.90)']  },
  { h: 22, colors: ['rgba(13,27,62,0.90)',   'rgba(10,10,26,0.90)',   'rgba(0,0,16,0.90)']    },
  { h: 24, colors: ['rgba(10,10,26,0.90)',   'rgba(13,27,62,0.90)',   'rgba(26,26,46,0.90)']  },
];

function getCurrentHour() {
  const now = new Date();
  return now.getHours() + now.getMinutes() / 60;
}

function lerpChannel(a, b, t) {
  return Math.round(a + (b - a) * t);
}

function lerpRgba(c1, c2, t) {
  const parse = s => s.match(/[\d.]+/g).map(Number);
  const [r1,g1,b1,a1] = parse(c1);
  const [r2,g2,b2,a2] = parse(c2);
  return `rgba(${lerpChannel(r1,r2,t)},${lerpChannel(g1,g2,t)},${lerpChannel(b1,b2,t)},${a1})`;
}

function getSkyColors() {
  const h = getCurrentHour();
  let prev = SKY_PHASES.at(-2);
  let next = SKY_PHASES.at(-1);
  for (let i = 0; i < SKY_PHASES.length - 1; i++) {
    if (h >= SKY_PHASES[i].h && h < SKY_PHASES[i + 1].h) {
      prev = SKY_PHASES[i];
      next = SKY_PHASES[i + 1];
      break;
    }
  }
  const t = (h - prev.h) / (next.h - prev.h);
  return [0, 1, 2].map(i => lerpRgba(prev.colors[i], next.colors[i], t));
}

function updateSkyGradient() {
  const [top, mid, bot] = getSkyColors();
  document.documentElement.style.setProperty('--sky-top', top);
  document.documentElement.style.setProperty('--sky-mid', mid);
  document.documentElement.style.setProperty('--sky-bot', bot);
}

updateSkyGradient();
setInterval(updateSkyGradient, 60_000);

// ════════════════════════════════════════════════════════════
// STATE
// ════════════════════════════════════════════════════════════
let durationSecs = 0;
let startAt = null;     // Date — cuando arranca la sesión
let endAt = null;       // Date — cuando termina la sesión
let timerRunning = false;
let waiting = false;
let pauseRemaining = null;
let timerJob = null;
let waitJob = null;
let selectedQuarter = null;  // Date
let waitWarnDone = false;

// ════════════════════════════════════════════════════════════
// HELPERS
// ════════════════════════════════════════════════════════════
function fmtHour(date) {
  return `${date.getHours()}:${String(date.getMinutes()).padStart(2, '0')}`;
}

function fmtCountdown(secs) {
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = Math.floor(secs % 60);
  if (h > 0) return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}

function nextQuarters(n = 6) {
  const now = new Date();
  const pastMins = now.getMinutes() - (now.getMinutes() % 15);
  const current = new Date(now);
  current.setSeconds(0); current.setMilliseconds(0); current.setMinutes(pastMins);

  const prev = new Date(current.getTime() - 15 * 60 * 1000);
  const results = [prev, current];
  for (let i = 1; i <= n; i++) {
    results.push(new Date(current.getTime() + i * 15 * 60 * 1000));
  }
  return results;
}

function showError(msg) {
  const el = document.getElementById('errorMsg');
  el.textContent = msg;
  el.classList.remove('hidden');
  setTimeout(() => el.classList.add('hidden'), 3000);
}

function clearError() {
  document.getElementById('errorMsg').classList.add('hidden');
}

// ════════════════════════════════════════════════════════════
// PANELS
// ════════════════════════════════════════════════════════════
function showPanel(id) {
  ['panelSetup', 'panelWait', 'panelTimer'].forEach(p => {
    document.getElementById(p).classList.toggle('hidden', p !== id);
  });
}

// ════════════════════════════════════════════════════════════
// QUARTER BUTTONS
// ════════════════════════════════════════════════════════════
function buildQuarterButtons() {
  const grid = document.getElementById('quarterGrid');
  grid.innerHTML = '';
  const now = new Date();
  const quarters = nextQuarters(6);
  // show only first 6 (2 past + 4 future) in grid 3x2
  quarters.slice(0, 6).forEach(t => {
    const isPast = t <= now;
    const btn = document.createElement('button');
    btn.className = 'quarter-btn' + (isPast ? ' past' : '');
    btn.textContent = fmtHour(t);
    btn.addEventListener('click', () => selectQuarter(t, btn));
    grid.appendChild(btn);
  });
}

function selectQuarter(t, btn) {
  selectedQuarter = t;
  document.querySelectorAll('.quarter-btn').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  clearError();
  document.getElementById('customTimeRow').classList.add('hidden');
}

// ════════════════════════════════════════════════════════════
// SESSION SUMMARY (placeholder — could hook into saved sessions)
// ════════════════════════════════════════════════════════════
function updateSessionSummary() {
  // Placeholder — shows nothing unless you hook a sessions store
  document.getElementById('sessionSummary').textContent = '';
}

// ════════════════════════════════════════════════════════════
// DURATION SELECTION
// ════════════════════════════════════════════════════════════
document.querySelectorAll('.dur-btn[data-mins]').forEach(btn => {
  btn.addEventListener('click', () => {
    const mins = parseInt(btn.dataset.mins);
    durationSecs = mins * 60;
    document.querySelectorAll('.dur-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    clearError();
    document.getElementById('customDurRow').classList.add('hidden');
  });
});

document.getElementById('customDurBtn').addEventListener('click', () => {
  const row = document.getElementById('customDurRow');
  row.classList.toggle('hidden');
  if (!row.classList.contains('hidden')) {
    document.getElementById('customDurInput').focus();
  }
});

document.getElementById('customDurOk').addEventListener('click', applyCustomDur);
document.getElementById('customDurInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') applyCustomDur();
});

function applyCustomDur() {
  const val = parseInt(document.getElementById('customDurInput').value);
  if (!val || val <= 0) return;
  durationSecs = val * 60;
  document.querySelectorAll('.dur-btn').forEach(b => b.classList.remove('selected'));
  document.getElementById('customDurRow').classList.add('hidden');
  document.getElementById('customDurInput').value = '';
  clearError();
}

// ════════════════════════════════════════════════════════════
// PLANIFICAR (hora manual)
// ════════════════════════════════════════════════════════════
document.getElementById('planificarBtn').addEventListener('click', () => {
  const row = document.getElementById('customTimeRow');
  row.classList.toggle('hidden');
  if (!row.classList.contains('hidden')) {
    document.getElementById('customTimeInput').focus();
  }
});

document.getElementById('customTimeOk').addEventListener('click', applyCustomTime);
document.getElementById('customTimeInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') applyCustomTime();
});

function applyCustomTime() {
  const raw = document.getElementById('customTimeInput').value.trim();
  document.getElementById('customTimeInput').value = '';
  const match = raw.match(/^(\d{1,2}):(\d{2})$/);
  if (!match) { showError('Formato: HH:MM (ej. 19:15)'); return; }
  const now = new Date();
  const t = new Date(now);
  t.setHours(parseInt(match[1]), parseInt(match[2]), 0, 0);
  if (t <= now) t.setDate(t.getDate() + 1);
  selectedQuarter = t;
  document.querySelectorAll('.quarter-btn').forEach(b => b.classList.remove('selected'));
  document.getElementById('customTimeRow').classList.add('hidden');
  schedule(t);
}

// ════════════════════════════════════════════════════════════
// INICIAR SESIÓN
// ════════════════════════════════════════════════════════════
document.getElementById('startNowBtn').addEventListener('click', () => {
  if (!durationSecs) { showError('Primero elegí la duración'); return; }
  const t = selectedQuarter || new Date();
  schedule(t);
});

function schedule(startDt) {
  if (!durationSecs) { showError('Primero elegí la duración'); return; }
  const now = new Date();
  endAt = new Date(startDt.getTime() + durationSecs * 1000);

  if (startDt <= now) {
    const elapsed = (now - startDt) / 1000;
    if (elapsed > 1800) { showError('Pasaron más de 30 min del inicio'); return; }
    startAt = startDt;
    const remaining = durationSecs - elapsed;
    startTimer(remaining);
    return;
  }

  // Futuro → modo espera
  startAt = startDt;
  waiting = true;
  waitWarnDone = false;
  document.getElementById('waitInfo').textContent =
    `${durationSecs / 60} min  ·  ${fmtHour(startDt)}`;
  showPanel('panelWait');
  tickWait();
}

// ════════════════════════════════════════════════════════════
// WAIT TICK
// ════════════════════════════════════════════════════════════
function tickWait() {
  if (!waiting) return;
  const delta = (startAt - new Date()) / 1000;
  if (delta <= 0) {
    waiting = false;
    startTimer(durationSecs);
    return;
  }
  const label = document.getElementById('waitLabel');
  label.textContent = fmtCountdown(delta);
  label.style.color = delta <= 60 ? '#ff4444' : 'white';
  waitJob = setTimeout(tickWait, 1000);
}

document.getElementById('waitCancelBtn').addEventListener('click', () => {
  waiting = false;
  clearTimeout(waitJob);
  buildQuarterButtons();
  showPanel('panelSetup');
});

// ════════════════════════════════════════════════════════════
// TIMER
// ════════════════════════════════════════════════════════════
function startTimer(remaining) {
  clearTimeout(timerJob);
  endAt = new Date(Date.now() + remaining * 1000);
  timerRunning = true;
  pauseRemaining = null;
  document.getElementById('timerStartsLabel').textContent = 'Tiempo restante:';
  document.getElementById('pauseBtn').textContent = '⏸';
  showPanel('panelTimer');
  tickTimer();
}

function tickTimer() {
  if (!timerRunning) return;
  const remaining = Math.max(0, (endAt - Date.now()) / 1000);
  const label = document.getElementById('timerLabel');
  label.textContent = fmtCountdown(remaining);
  label.style.color = remaining <= 60 ? '#ff4444' : 'white';

  // Progress bar
  const pct = ((durationSecs - remaining) / durationSecs) * 100;
  document.getElementById('progressFill').style.width = pct + '%';

  if (remaining <= 0) {
    timerRunning = false;
    label.textContent = '00:00';
    document.getElementById('progressFill').style.width = '100%';
    return;
  }
  timerJob = setTimeout(tickTimer, 500);
}

// Pause/resume
document.getElementById('pauseBtn').addEventListener('click', () => {
  if (timerRunning) {
    pauseRemaining = Math.max(0, (endAt - Date.now()) / 1000);
    timerRunning = false;
    clearTimeout(timerJob);
    document.getElementById('pauseBtn').textContent = '▶';
  } else {
    startTimer(pauseRemaining || durationSecs);
    document.getElementById('pauseBtn').textContent = '⏸';
  }
});

// Reset
document.getElementById('resetBtn').addEventListener('click', () => {
  timerRunning = false;
  clearTimeout(timerJob);
  startTimer(durationSecs);
});

// Edit (volver a setup)
document.getElementById('editBtn').addEventListener('click', goToSetup);

// ════════════════════════════════════════════════════════════
// CALENDAR & TASKS (placeholder — abre en futuro)
// ════════════════════════════════════════════════════════════
function openCalendar() {
  // TODO: implementar vista calendario
  console.log('Abrir calendario');
}

function openTasks() {
  // TODO: implementar vista tareas
  console.log('Abrir tareas');
}

document.getElementById('calBtn').addEventListener('click', openCalendar);
document.getElementById('tasksSetupBtn').addEventListener('click', openTasks);
document.getElementById('calTimerBtn').addEventListener('click', openCalendar);
document.getElementById('tasksTimerBtn').addEventListener('click', openTasks);

// ════════════════════════════════════════════════════════════
// SETUP RESET
// ════════════════════════════════════════════════════════════
function goToSetup() {
  timerRunning = false;
  waiting = false;
  clearTimeout(timerJob);
  clearTimeout(waitJob);
  buildQuarterButtons();
  updateSessionSummary();
  showPanel('panelSetup');
}

// ════════════════════════════════════════════════════════════
// CLOSE
// ════════════════════════════════════════════════════════════
document.getElementById('closeBtn').addEventListener('click', () => {
  try {
    const { ipcRenderer } = require('electron');
    ipcRenderer.send('close-app');
  } catch(e) {
    window.close();
  }
});

// ════════════════════════════════════════════════════════════
// INIT
// ════════════════════════════════════════════════════════════
buildQuarterButtons();
updateSessionSummary();
showPanel('panelSetup');
